rm -rf debug.*.lua
time luajit wasm.lua
