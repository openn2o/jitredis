

return  {
    ["ccm1"] = "ccm1_string"
};