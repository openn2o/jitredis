export PATH=$PATH:/Users/dvtplayer/Desktop/openresty-1.17.8.2/build/LuaJIT-2.1-20200102/src
