local server = require("suma_apollo_server");
---
-- 代码管理
---

local _M = {}

---保存code到持久化区
_M.set_code = server.suma_code_set;

---初始化的代码到目标机
_M.init_code = server.suma_code_select_tracker_vip;
return _M;